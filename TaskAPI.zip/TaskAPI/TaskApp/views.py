
from django.shortcuts import render
from TaskApp.models import Task
from TaskApp.serializers import TaskSerializer
from rest_framework.viewsets import ModelViewSet

class TaskViewSet(ModelViewSet):
    queryset = Task.objects.all().order_by('-date_created')
    serializer_class = TaskSerializer

class DueTaskViewSet(ModelViewSet):
    queryset = Task.objects.all().order_by('-date_created')\
                            .filter(completed=False)
    serializer_class = TaskSerializer

class CompletedTaskViewSet(ModelViewSet):
    queryset = Task.objects.all().order_by('-date_created')\
                            .filter(completed=True)
    serializer_class = TaskSerializer





from rest_framework.parsers import MultiPartParser,JSONParser,FileUploadParser
from .models import ImageTask
from .serializers import ImageTaskSerializer

class ImageTaskView(ModelViewSet):
    queryset = ImageTask.objects.all()
    serializer_class = ImageTaskSerializer

    parser_classes = (MultiPartParser,FileUploadParser)

    # def create(self, request, *args, **kwargs):
    #     images = request.FILES.getlist('images')
    #     ImageTask.objects.create(images=images)






from django.http import HttpResponse
def simple_upload(request):

    if request.method == 'POST':
        my_images = request.FILES.getlist('images')
        # print(my_images)
        image_list = []
        for image in my_images:
            image_list.append(image.name)
            ImageTask.objects.create(images=image)
        return HttpResponse('Saved Images')

    return render(request, 'upload.html')



