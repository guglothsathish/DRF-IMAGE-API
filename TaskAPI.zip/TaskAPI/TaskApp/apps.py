from django.apps import AppConfig


class TaskappConfig(AppConfig):
    name = 'TaskApp'
